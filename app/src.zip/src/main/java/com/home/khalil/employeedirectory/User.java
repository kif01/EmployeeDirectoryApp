package com.home.khalil.employeedirectory;

/**
 * Created by khalil on 3/29/18.
 */

public class User {
    private String id;
    private String role;

    public User(String id, String role){
        this.id=id;
        this.role=role;
    }
}
